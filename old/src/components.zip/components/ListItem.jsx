import axios from "axios";
import clsx from "clsx";

const ListItem = ({ todo, setTodos }) => {
    const updateTodo = () => {
        axios
            .put(`http://localhost:8000/todos/${todo.id}`, {
                ...todo,
                completed: !todo.completed,
            })
            .then((res) => {
                setTodos((prev) =>
                    prev.map((todoObj) => {
                        if (todoObj.id == todo.id) {
                            return { ...todo, completed: !todo.completed };
                        } else {
                            return todoObj;
                        }
                    })
                );
            })
            .catch((err) => {})
            .finally(() => {});
    };

    const deleteTodo = () => {
        axios
            .delete(`http://localhost:8000/todos/${todo.id}`)
            .then((res) => {
                setTodos((prev) =>
                    prev.filter((todoObj) => todo.id != todoObj.id)
                );
            })
            .catch((err) => {})
            .finally(() => {});
    };

    return (
        <li className={clsx({ checked: todo.completed == true })}>
            <span onClick={updateTodo}>{todo.title}</span>
            <span className="close" onClick={deleteTodo}>
                x
            </span>
        </li>
    );
};

export default ListItem;